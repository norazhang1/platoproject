from flask import Flask, render_template, request

try:
    from transformers import pipeline
    emotion_classifier = pipeline("text-classification", model="bhadresh-savani/distilbert-base-uncased-emotion")
except ModuleNotFoundError:
    emotion_classifier = None

app = Flask(__name__)

advice_dict = {
    "joy": "Keep doing what brings you happiness. Share your joy with someone else today.",
    "sadness": "Take deep breaths, journal your feelings, or talk to a friend. It's okay to feel down.",
    "anger": "Step away for a moment. Try going for a walk or doing something creative to cool off.",
    "fear": "Ground yourself with your senses. Remind yourself what's in your control right now.",
    "love": "Express it! Write a note, send a message, or do a kind act for someone.",
    "surprise": "Take a moment to reflect on this. Is it something exciting or something uncertain?",
    "neutral": "You seem balanced right now. Take this time to recharge or focus calmly on your goals."
}

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/detect', methods=['POST'])
def detect():
    user_input = request.form['text']

    if emotion_classifier is None:
        return render_template('result.html', emotion="error", score=0.0, text=user_input,
                               advice="Model could not be loaded. Please ensure 'transformers' is installed.")

    result = emotion_classifier(user_input)[0]
    emotion = result['label'].lower()
    score = round(result['score'], 2)
    advice = advice_dict.get(emotion, "Take a moment to reflect on how you feel.")

    return render_template('result.html', emotion=emotion, score=score, text=user_input, advice=advice)

if __name__ == '__main__':
    app.run(debug=True)
